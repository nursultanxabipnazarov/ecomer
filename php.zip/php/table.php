<?php
require('database.php');

$sql="SELECT * FROM users";
$stmt=$conn->prepare($sql);
$stmt->execute();
$users=$stmt->fetchAll();
// echo "<pre>";
// print_r($users);
// echo "</pre>";
?>


<!DOCTYPE html>
<html>
<head>
<style>
table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
</style>
</head>
<body>
<center><h2>Users</h2></center>
<center>
<table>
  <tr>
    <th>name</th>
    <th>surname</th>
    <th>phone</th>
    <th>email</th>
    <th>age</th>
  </tr>
  <?php foreach($users as $val): ?>
  <tr>
    <td><?php echo $val['name']; ?></td>
    <td><?php echo $val['surname']; ?></td>
    <td><?php echo $val['phone']; ?></td>
    <td><?php echo $val['email']; ?></td>
    <td><?php echo $val['age']; ?></td>
  </tr>
  <?php endforeach; ?>
</table>
</center>
<center><h2><a href="index.php">AddUser</a></h2></center>
</body>
</html>
