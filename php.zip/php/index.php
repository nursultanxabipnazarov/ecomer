<?php
require('database.php');
// $sql="SELECT * FROM users";
// $stmt=$conn->prepare($sql);
// $stmt->execute();
// $users=$stmt->fetchAll();
// echo "<pre>";
// print_r($users);
// echo "</pre>";

// $sql="SELECT * FROM users WHERE name = :name";

// $stmt=$conn->prepare($sql);
// $stmt->execute(['name'=>'Ilxam']);
// $user = $stmt -> fetchAll();
echo "<pre>";
print_r($_POST);
echo "</pre>";

if($_SERVER['REQUEST_METHOD']=='POST' && isset($_POST['submit']))
{
    $name=$_POST['name'];
    $surname=$_POST['surname'];
    $phone=$_POST['phone'];
    $email=$_POST['email'];
    $age=$_POST['age'];
  
    $data=
    [
        'name'=>$name,
        'surname'=>$surname,
        'phone'=>$phone,
        'email'=>$email,
        'age'=>$age
    ];
    $sql="INSERT INTO users (name,surname,phone,email,age) VALUES (:name,:surname,:phone,:email,:age)";
    $stmt=$conn->prepare($sql);
    $stmt->execute($data);
    header("Location: table.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <form action="" method="post">
        name: <input type="text" name="name"><br>
        surname: <input type="text" name="surname" id=""><br>
        phone:+998<input type="number" name="phone" id=""><br>
        email: <input type="email" name="email" id=""><br>
        age: <input type="number" name="age" id=""><br>
        <input type="submit" name="submit" value="submit">
    </form>
</body>
</html>